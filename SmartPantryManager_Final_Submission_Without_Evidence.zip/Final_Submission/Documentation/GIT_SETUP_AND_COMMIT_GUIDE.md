# GitHub evidence guide

The assignment requires genuine incremental development history. Do not fabricate or backdate commits.

For future changes, initialise Git and commit real work as it happens. Example meaningful milestones:
- Initial Android Studio project setup
- Add SQLite schema
- Implement pantry model and CRUD
- Add pantry RecyclerView
- Add ingredient validation
- Seed recipe database
- Implement recipe detail
- Implement strict matching
- Add settings preference
- Improve Material UI
- Fix unit conversion edge cases
- Add documentation

Create a public GitHub repository (or give the marker access if private), push the real repository, and place its URL in the report.
