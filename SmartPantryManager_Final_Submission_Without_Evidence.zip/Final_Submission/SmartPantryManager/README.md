# Smart Pantry Manager

Smart Pantry Manager is a Java Android application that tracks pantry ingredients and suggests only recipes the user can make with all required ingredients in sufficient quantities.

## Database choice
SQLite via `SQLiteOpenHelper` was selected because the assignment requires persistent CRUD data and the application is designed to work locally without a server.

## Features
- Pantry Create, Read, Update and Delete
- Persistent SQLite storage
- 15 seeded recipes
- Strict recipe matching
- Basic unit conversion (g/kg and ml/L)
- Simple ingredient-name normalization
- Suggested Recipes and Recipe Detail
- Settings preference
- Custom RecyclerView adapters
- Recipe management (additional feature)

## Run
1. Open this folder in Android Studio.
2. Allow Gradle to sync.
3. Select an emulator/device running Android 7.0 (API 24) or newer.
4. Run the `app` configuration.
5. On first run, SQLite creates the database and seeds the recipe collection.

## Demonstrating strict matching
For Tomato Pasta add: pasta 200 g, tomato 3 pieces and garlic 2 pieces. The recipe should appear. Remove garlic or reduce it below 2 pieces and it should disappear.

## Important submission evidence
The final institutional submission still requires the student's genuine GitHub history, real screenshots of the running app, and a narrated 5-7 minute demonstration video.
