package com.example.smartpantrymanager.adapter;
import android.view.*;import android.widget.*;import androidx.annotation.NonNull;import androidx.recyclerview.widget.RecyclerView;
import com.example.smartpantrymanager.R;import com.example.smartpantrymanager.model.PantryItem;import java.util.*;
public class PantryAdapter extends RecyclerView.Adapter<PantryAdapter.H>{
 public interface L{void edit(PantryItem p);void delete(PantryItem p);}
 private final List<PantryItem>a;private final L l;public PantryAdapter(List<PantryItem>a,L l){this.a=a;this.l=l;}
 public H onCreateViewHolder(@NonNull ViewGroup p,int t){return new H(LayoutInflater.from(p.getContext()).inflate(R.layout.item_pantry,p,false));}
 public void onBindViewHolder(@NonNull H h,int i){PantryItem p=a.get(i);h.n.setText(p.getName());h.q.setText(fmt(p.getQuantity())+" "+p.getUnit()+(p.getExpiryDate()==null||p.getExpiryDate().isEmpty()?"":" • Expires "+p.getExpiryDate()));h.e.setOnClickListener(v->l.edit(p));h.d.setOnClickListener(v->l.delete(p));}
 public int getItemCount(){return a.size();} private String fmt(double x){return x==Math.rint(x)?String.valueOf((long)x):String.valueOf(x);}
 static class H extends RecyclerView.ViewHolder{TextView n,q;ImageButton e,d;H(View v){super(v);n=v.findViewById(R.id.name);q=v.findViewById(R.id.qty);e=v.findViewById(R.id.edit);d=v.findViewById(R.id.delete);}}
}
