package com.example.smartpantrymanager;
import android.os.Bundle;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import com.example.smartpantrymanager.database.DatabaseHelper;import com.example.smartpantrymanager.model.Recipe;
public class RecipeDetailActivity extends AppCompatActivity{
 protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_recipe_detail);findViewById(R.id.back).setOnClickListener(v->finish());Recipe r=new DatabaseHelper(this).getRecipeById(getIntent().getIntExtra("RECIPE_ID",-1));if(r==null){finish();return;}((TextView)findViewById(R.id.title)).setText(r.getName());StringBuilder s=new StringBuilder();for(Recipe.IngredientRequirement x:r.getIngredients())s.append("• ").append(fmt(x.getQuantity())).append(" ").append(x.getUnit()).append(" ").append(x.getName()).append("\n");((TextView)findViewById(R.id.ingredients)).setText(s.toString().trim());((TextView)findViewById(R.id.method)).setText(r.getMethod());}
 private String fmt(double x){return x==Math.rint(x)?String.valueOf((long)x):String.valueOf(x);}
}
