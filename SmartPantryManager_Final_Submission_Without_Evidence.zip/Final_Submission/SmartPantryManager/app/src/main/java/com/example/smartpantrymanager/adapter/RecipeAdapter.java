package com.example.smartpantrymanager.adapter;
import android.view.*;import android.widget.*;import androidx.annotation.NonNull;import androidx.recyclerview.widget.RecyclerView;
import com.example.smartpantrymanager.R;import com.example.smartpantrymanager.model.Recipe;import java.util.*;
public class RecipeAdapter extends RecyclerView.Adapter<RecipeAdapter.H>{
 public interface L{void click(Recipe r);}private final List<Recipe>a;private final L l;public RecipeAdapter(List<Recipe>a,L l){this.a=a;this.l=l;}
 public H onCreateViewHolder(@NonNull ViewGroup p,int t){return new H(LayoutInflater.from(p.getContext()).inflate(R.layout.item_recipe,p,false));}
 public void onBindViewHolder(@NonNull H h,int i){Recipe r=a.get(i);h.t.setText(r.getName());h.s.setText(r.getIngredients().size()+" required ingredient(s)");h.itemView.setOnClickListener(v->l.click(r));}
 public int getItemCount(){return a.size();}static class H extends RecyclerView.ViewHolder{TextView t,s;H(View v){super(v);t=v.findViewById(R.id.recipeName);s=v.findViewById(R.id.recipeSub);}}
}
