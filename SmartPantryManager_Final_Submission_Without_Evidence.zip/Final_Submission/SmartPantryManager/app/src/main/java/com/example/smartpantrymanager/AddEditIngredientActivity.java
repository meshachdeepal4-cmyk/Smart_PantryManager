package com.example.smartpantrymanager;
import android.os.Bundle;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;
import com.example.smartpantrymanager.database.DatabaseHelper;import com.example.smartpantrymanager.model.PantryItem;
import com.google.android.material.textfield.TextInputEditText;
public class AddEditIngredientActivity extends AppCompatActivity{
 private DatabaseHelper db;private int id=-1;private TextInputEditText name,qty,expiry;private Spinner unit;
 protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_add_edit_ingredient);db=new DatabaseHelper(this);name=findViewById(R.id.name);qty=findViewById(R.id.qty);expiry=findViewById(R.id.expiry);unit=findViewById(R.id.unit);
  String[] u={"pieces","g","kg","ml","L","can"};unit.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,u));id=getIntent().getIntExtra("ID",-1);if(id!=-1)fill();findViewById(R.id.save).setOnClickListener(v->save());findViewById(R.id.cancel).setOnClickListener(v->finish());}
 private void fill(){PantryItem p=db.getPantryItem(id);if(p==null)return;name.setText(p.getName());qty.setText(String.valueOf(p.getQuantity()));expiry.setText(p.getExpiryDate());for(int i=0;i<unit.getCount();i++)if(unit.getItemAtPosition(i).toString().equals(p.getUnit()))unit.setSelection(i);}
 private void save(){String n=txt(name),q=txt(qty);if(n.isEmpty()){name.setError("Ingredient name is required");return;}double d;try{d=Double.parseDouble(q);if(d<=0)throw new Exception();}catch(Exception e){qty.setError("Enter a quantity greater than zero");return;}PantryItem p=new PantryItem(id,n,d,unit.getSelectedItem().toString(),txt(expiry));if(id==-1)db.insertPantryItem(p);else db.updatePantryItem(p);finish();}
 private String txt(TextInputEditText e){return e.getText()==null?"":e.getText().toString().trim();}
}
