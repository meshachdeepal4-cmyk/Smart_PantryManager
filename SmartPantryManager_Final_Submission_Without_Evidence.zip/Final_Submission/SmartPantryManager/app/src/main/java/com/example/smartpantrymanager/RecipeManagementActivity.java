package com.example.smartpantrymanager;
import android.content.*;import android.os.Bundle;import android.view.*;import androidx.appcompat.app.*;import androidx.recyclerview.widget.*;
import com.example.smartpantrymanager.adapter.RecipeAdapter;import com.example.smartpantrymanager.database.DatabaseHelper;import com.example.smartpantrymanager.model.Recipe;import java.util.*;
public class RecipeManagementActivity extends AppCompatActivity implements RecipeAdapter.L{
 private DatabaseHelper db;private final ArrayList<Recipe>a=new ArrayList<>();private RecipeAdapter ad;
 protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_recipe_management);db=new DatabaseHelper(this);RecyclerView r=findViewById(R.id.list);r.setLayoutManager(new LinearLayoutManager(this));ad=new RecipeAdapter(a,this);r.setAdapter(ad);findViewById(R.id.back).setOnClickListener(v->finish());findViewById(R.id.add).setOnClickListener(v->startActivity(new Intent(this,RecipeEditActivity.class)));}
 protected void onResume(){super.onResume();a.clear();a.addAll(db.getAllRecipes());ad.notifyDataSetChanged();}
 public void click(Recipe r){new AlertDialog.Builder(this).setTitle(r.getName()).setItems(new String[]{"View","Edit","Delete"},(d,w)->{if(w==0){Intent i=new Intent(this,RecipeDetailActivity.class);i.putExtra("RECIPE_ID",r.getId());startActivity(i);}else if(w==1){Intent i=new Intent(this,RecipeEditActivity.class);i.putExtra("RECIPE_ID",r.getId());startActivity(i);}else new AlertDialog.Builder(this).setTitle("Delete recipe?").setPositiveButton("Delete",(x,y)->{db.deleteRecipe(r.getId());onResume();}).setNegativeButton("Cancel",null).show();}).show();}
}
