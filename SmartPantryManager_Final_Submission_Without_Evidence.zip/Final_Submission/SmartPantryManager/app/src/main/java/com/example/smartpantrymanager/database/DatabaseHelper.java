package com.example.smartpantrymanager.database;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import com.example.smartpantrymanager.model.*;
import java.util.*;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DB="smart_pantry.db";
    public DatabaseHelper(Context c){super(c,DB,null,1);}
    @Override public void onConfigure(SQLiteDatabase db){super.onConfigure(db);db.setForeignKeyConstraintsEnabled(true);}
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE pantry(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,quantity REAL NOT NULL,unit TEXT NOT NULL,expiryDate TEXT)");
        db.execSQL("CREATE TABLE recipes(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,method TEXT NOT NULL)");
        db.execSQL("CREATE TABLE recipe_ingredients(id INTEGER PRIMARY KEY AUTOINCREMENT,recipeId INTEGER NOT NULL,name TEXT NOT NULL,quantity REAL NOT NULL,unit TEXT NOT NULL,FOREIGN KEY(recipeId) REFERENCES recipes(id) ON DELETE CASCADE)");
        seed(db);
    }
    @Override public void onUpgrade(SQLiteDatabase db,int o,int n){}

    public long insertPantryItem(PantryItem p){ContentValues v=pantryValues(p);return getWritableDatabase().insert("pantry",null,v);}
    public int updatePantryItem(PantryItem p){return getWritableDatabase().update("pantry",pantryValues(p),"id=?",new String[]{String.valueOf(p.getId())});}
    public int deletePantryItem(int id){return getWritableDatabase().delete("pantry","id=?",new String[]{String.valueOf(id)});}
    private ContentValues pantryValues(PantryItem p){ContentValues v=new ContentValues();v.put("name",p.getName().trim());v.put("quantity",p.getQuantity());v.put("unit",p.getUnit());v.put("expiryDate",p.getExpiryDate());return v;}
    public PantryItem getPantryItem(int id){
        try(Cursor c=getReadableDatabase().query("pantry",null,"id=?",new String[]{String.valueOf(id)},null,null,null)){
            if(c.moveToFirst()) return pantry(c); return null;
        }
    }
    public ArrayList<PantryItem> getAllPantryItems(){
        ArrayList<PantryItem> a=new ArrayList<>();
        try(Cursor c=getReadableDatabase().query("pantry",null,null,null,null,null,"name COLLATE NOCASE")){
            while(c.moveToNext())a.add(pantry(c));
        } return a;
    }
    private PantryItem pantry(Cursor c){return new PantryItem(c.getInt(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getDouble(c.getColumnIndexOrThrow("quantity")),c.getString(c.getColumnIndexOrThrow("unit")),c.getString(c.getColumnIndexOrThrow("expiryDate")));}

    public ArrayList<Recipe> getAllRecipes(){
        ArrayList<Recipe>a=new ArrayList<>(); SQLiteDatabase db=getReadableDatabase();
        try(Cursor c=db.query("recipes",null,null,null,null,null,"name COLLATE NOCASE")){
            while(c.moveToNext()){Recipe r=new Recipe(c.getInt(0),c.getString(1),c.getString(2));loadIngredients(db,r);a.add(r);}
        } return a;
    }
    public Recipe getRecipeById(int id){
        SQLiteDatabase db=getReadableDatabase();
        try(Cursor c=db.query("recipes",null,"id=?",new String[]{String.valueOf(id)},null,null,null)){
            if(!c.moveToFirst())return null; Recipe r=new Recipe(c.getInt(0),c.getString(1),c.getString(2));loadIngredients(db,r);return r;
        }
    }
    private void loadIngredients(SQLiteDatabase db,Recipe r){
        try(Cursor c=db.query("recipe_ingredients",null,"recipeId=?",new String[]{String.valueOf(r.getId())},null,null,"id")){
            while(c.moveToNext())r.addIngredient(c.getString(c.getColumnIndexOrThrow("name")),c.getDouble(c.getColumnIndexOrThrow("quantity")),c.getString(c.getColumnIndexOrThrow("unit")));
        }
    }
    public int deleteRecipe(int id){return getWritableDatabase().delete("recipes","id=?",new String[]{String.valueOf(id)});}
    public long saveRecipeWithIngredients(int id,String name,String method,List<Recipe.IngredientRequirement> list){
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction(); long rid=-1;
        try{
            ContentValues rv=new ContentValues();rv.put("name",name.trim());rv.put("method",method.trim());
            if(id==-1)rid=db.insertOrThrow("recipes",null,rv);
            else {if(db.update("recipes",rv,"id=?",new String[]{String.valueOf(id)})==0)throw new Exception();rid=id;db.delete("recipe_ingredients","recipeId=?",new String[]{String.valueOf(id)});}
            for(Recipe.IngredientRequirement x:list){ContentValues v=new ContentValues();v.put("recipeId",rid);v.put("name",x.getName().trim());v.put("quantity",x.getQuantity());v.put("unit",x.getUnit());db.insertOrThrow("recipe_ingredients",null,v);}
            db.setTransactionSuccessful(); return rid;
        }catch(Exception e){return -1;}finally{db.endTransaction();}
    }
    private void seed(SQLiteDatabase db){
        db.beginTransaction();try{
            add(db,"Tomato Pasta","Boil pasta. Cook tomato and garlic, combine and serve.",new Object[][]{{"pasta",200d,"g"},{"tomato",3d,"pieces"},{"garlic",2d,"pieces"}});
            add(db,"Scrambled Eggs","Beat eggs with milk. Cook gently in butter.",new Object[][]{{"egg",3d,"pieces"},{"milk",50d,"ml"},{"butter",10d,"g"}});
            add(db,"Chicken Stir Fry","Cook chicken, then add sliced carrot and onion.",new Object[][]{{"chicken",300d,"g"},{"carrot",1d,"pieces"},{"onion",1d,"pieces"}});
            add(db,"Tuna Sandwich","Mix tuna with mayonnaise and place between bread.",new Object[][]{{"tuna",1d,"can"},{"bread",2d,"pieces"},{"mayonnaise",20d,"g"}});
            add(db,"French Toast","Whisk egg and milk, soak bread and pan-fry.",new Object[][]{{"egg",2d,"pieces"},{"bread",2d,"pieces"},{"milk",100d,"ml"}});
            add(db,"Pancakes","Mix flour, milk and eggs. Fry portions until golden.",new Object[][]{{"flour",200d,"g"},{"milk",250d,"ml"},{"egg",2d,"pieces"}});
            add(db,"Garlic Pasta","Boil pasta and toss with cooked garlic and butter.",new Object[][]{{"pasta",200d,"g"},{"garlic",3d,"pieces"},{"butter",20d,"g"}});
            add(db,"Grilled Cheese Sandwich","Butter bread, add cheese and grill both sides.",new Object[][]{{"bread",2d,"pieces"},{"cheese",50d,"g"},{"butter",10d,"g"}});
            add(db,"Vegetable Rice","Cook rice and stir through cooked carrot and onion.",new Object[][]{{"rice",200d,"g"},{"carrot",1d,"pieces"},{"onion",1d,"pieces"}});
            add(db,"Omelette","Beat eggs, cook and fill with onion and cheese.",new Object[][]{{"egg",3d,"pieces"},{"onion",1d,"pieces"},{"cheese",30d,"g"}});
            add(db,"Tomato Soup","Cook tomato and onion until soft, blend and finish with butter.",new Object[][]{{"tomato",5d,"pieces"},{"onion",1d,"pieces"},{"butter",10d,"g"}});
            add(db,"Chicken Wrap","Cook chicken, add lettuce and roll into wraps.",new Object[][]{{"chicken",200d,"g"},{"wrap",2d,"pieces"},{"lettuce",50d,"g"}});
            add(db,"Fried Rice","Stir-fry cooked rice with egg, onion and carrot.",new Object[][]{{"rice",200d,"g"},{"egg",2d,"pieces"},{"onion",1d,"pieces"},{"carrot",1d,"pieces"}});
            add(db,"Banana Pancakes","Mash banana, combine with egg and flour, then fry.",new Object[][]{{"banana",2d,"pieces"},{"egg",2d,"pieces"},{"flour",100d,"g"}});
            add(db,"Cheesy Pasta","Boil pasta and stir in cheese and milk until creamy.",new Object[][]{{"pasta",200d,"g"},{"cheese",80d,"g"},{"milk",100d,"ml"}});
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    private void add(SQLiteDatabase db,String n,String m,Object[][] ing){
        ContentValues r=new ContentValues();r.put("name",n);r.put("method",m);long id=db.insert("recipes",null,r);
        for(Object[] x:ing){ContentValues v=new ContentValues();v.put("recipeId",id);v.put("name",(String)x[0]);v.put("quantity",(Double)x[1]);v.put("unit",(String)x[2]);db.insert("recipe_ingredients",null,v);}
    }
}
