package com.example.smartpantrymanager;
import android.content.*;import android.os.Bundle;import android.view.*;import android.widget.*;
import androidx.appcompat.app.*;import androidx.recyclerview.widget.*;
import com.example.smartpantrymanager.adapter.PantryAdapter;import com.example.smartpantrymanager.database.DatabaseHelper;import com.example.smartpantrymanager.model.PantryItem;
import java.util.*;
public class MainActivity extends AppCompatActivity implements PantryAdapter.L{
 private DatabaseHelper db;private final ArrayList<PantryItem>items=new ArrayList<>();private PantryAdapter ad;private TextView empty;
 protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);db=new DatabaseHelper(this);setSupportActionBar(findViewById(R.id.toolbar));
  RecyclerView r=findViewById(R.id.list);r.setLayoutManager(new LinearLayoutManager(this));ad=new PantryAdapter(items,this);r.setAdapter(ad);empty=findViewById(R.id.empty);
  findViewById(R.id.add).setOnClickListener(v->startActivity(new Intent(this,AddEditIngredientActivity.class)));load();}
 protected void onResume(){super.onResume();load();}
 private void load(){items.clear();items.addAll(db.getAllPantryItems());ad.notifyDataSetChanged();empty.setVisibility(items.isEmpty()?View.VISIBLE:View.GONE);}
 public boolean onCreateOptionsMenu(Menu m){getMenuInflater().inflate(R.menu.main_menu,m);return true;}
 public boolean onOptionsItemSelected(android.view.MenuItem x){int id=x.getItemId();if(id==R.id.suggested)startActivity(new Intent(this,SuggestedRecipesActivity.class));else if(id==R.id.manageRecipes)startActivity(new Intent(this,RecipeManagementActivity.class));else if(id==R.id.settings)startActivity(new Intent(this,SettingsActivity.class));else return super.onOptionsItemSelected(x);return true;}
 public void edit(PantryItem p){Intent i=new Intent(this,AddEditIngredientActivity.class);i.putExtra("ID",p.getId());startActivity(i);}
 public void delete(PantryItem p){new AlertDialog.Builder(this).setTitle("Delete ingredient?").setMessage("Remove "+p.getName()+" from your pantry?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{db.deletePantryItem(p.getId());load();}).show();}
}
