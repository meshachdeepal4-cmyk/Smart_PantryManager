package com.example.smartpantrymanager;
import android.content.*;import android.os.Bundle;import androidx.appcompat.app.AppCompatActivity;import com.google.android.material.switchmaterial.SwitchMaterial;
public class SettingsActivity extends AppCompatActivity{
 protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_settings);findViewById(R.id.back).setOnClickListener(v->finish());SharedPreferences p=getSharedPreferences("settings",MODE_PRIVATE);SwitchMaterial s=findViewById(R.id.alerts);s.setChecked(p.getBoolean("alerts",true));s.setOnCheckedChangeListener((v,c)->p.edit().putBoolean("alerts",c).apply());}
}
