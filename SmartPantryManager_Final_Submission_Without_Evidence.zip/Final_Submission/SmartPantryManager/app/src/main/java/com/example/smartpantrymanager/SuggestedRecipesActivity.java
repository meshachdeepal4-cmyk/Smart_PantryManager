package com.example.smartpantrymanager;
import android.content.*;import android.os.Bundle;import android.view.*;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import androidx.recyclerview.widget.*;
import com.example.smartpantrymanager.adapter.RecipeAdapter;import com.example.smartpantrymanager.database.DatabaseHelper;import com.example.smartpantrymanager.model.*;import java.util.*;
public class SuggestedRecipesActivity extends AppCompatActivity implements RecipeAdapter.L{
 private DatabaseHelper db;private final ArrayList<Recipe>shown=new ArrayList<>();private RecipeAdapter ad;private TextView empty;
 protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_suggested);db=new DatabaseHelper(this);RecyclerView r=findViewById(R.id.list);r.setLayoutManager(new LinearLayoutManager(this));ad=new RecipeAdapter(shown,this);r.setAdapter(ad);empty=findViewById(R.id.empty);findViewById(R.id.back).setOnClickListener(v->finish());}
 protected void onResume(){super.onResume();load();}
 private void load(){shown.clear();List<PantryItem> p=db.getAllPantryItems();for(Recipe r:db.getAllRecipes())if(canMake(r,p))shown.add(r);ad.notifyDataSetChanged();empty.setVisibility(shown.isEmpty()?View.VISIBLE:View.GONE);}
 private boolean canMake(Recipe r,List<PantryItem> p){for(Recipe.IngredientRequirement req:r.getIngredients()){double total=0;for(PantryItem x:p)if(name(x.getName()).equals(name(req.getName()))&&compatible(x.getUnit(),req.getUnit()))total+=base(x.getQuantity(),x.getUnit());if(total+0.000001<base(req.getQuantity(),req.getUnit()))return false;}return true;}
 private String name(String s){s=s.toLowerCase().trim().replace("-"," ").replace("_"," ").replaceAll("\\s+"," ");Map<String,String> m=new HashMap<>();m.put("tomatoes","tomato");m.put("eggs","egg");m.put("potatoes","potato");m.put("carrots","carrot");m.put("onions","onion");m.put("bananas","banana");m.put("wraps","wrap");return m.getOrDefault(s,s);}
 private String u(String s){s=s.toLowerCase().trim();if(s.matches("grams?|g"))return"g";if(s.matches("kilograms?|kg"))return"kg";if(s.matches("millilit(er|re)s?|ml"))return"ml";if(s.matches("lit(er|re)s?|l"))return"l";if(s.matches("pieces?|pcs?|pc"))return"piece";if(s.matches("cans?"))return"can";return s;}
 private boolean compatible(String a,String b){a=u(a);b=u(b);return a.equals(b)||(a.equals("g")&&b.equals("kg"))||(a.equals("kg")&&b.equals("g"))||(a.equals("ml")&&b.equals("l"))||(a.equals("l")&&b.equals("ml"));}
 private double base(double q,String unit){String x=u(unit);if(x.equals("kg")||x.equals("l"))return q*1000;return q;}
 public void click(Recipe r){Intent i=new Intent(this,RecipeDetailActivity.class);i.putExtra("RECIPE_ID",r.getId());startActivity(i);}
}
