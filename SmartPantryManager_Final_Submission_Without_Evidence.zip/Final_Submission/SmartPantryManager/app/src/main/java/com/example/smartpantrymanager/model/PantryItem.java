package com.example.smartpantrymanager.model;
public class PantryItem {
    private int id; private String name, unit, expiryDate; private double quantity;
    public PantryItem(int id,String name,double quantity,String unit,String expiryDate){
        this.id=id;this.name=name;this.quantity=quantity;this.unit=unit;this.expiryDate=expiryDate;
    }
    public int getId(){return id;} public void setId(int id){this.id=id;}
    public String getName(){return name;} public void setName(String v){name=v;}
    public double getQuantity(){return quantity;} public void setQuantity(double v){quantity=v;}
    public String getUnit(){return unit;} public void setUnit(String v){unit=v;}
    public String getExpiryDate(){return expiryDate;} public void setExpiryDate(String v){expiryDate=v;}
}
