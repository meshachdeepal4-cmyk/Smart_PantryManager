package com.example.smartpantrymanager.model;
import java.util.ArrayList;
public class Recipe {
    private int id; private String name, method;
    private final ArrayList<IngredientRequirement> ingredients=new ArrayList<>();
    public Recipe(int id,String name,String method){this.id=id;this.name=name;this.method=method;}
    public int getId(){return id;} public String getName(){return name;} public String getMethod(){return method;}
    public void setName(String v){name=v;} public void setMethod(String v){method=v;}
    public ArrayList<IngredientRequirement> getIngredients(){return ingredients;}
    public void addIngredient(String n,double q,String u){ingredients.add(new IngredientRequirement(n,q,u));}
    public static class IngredientRequirement {
        private final String name,unit; private final double quantity;
        public IngredientRequirement(String n,double q,String u){name=n;quantity=q;unit=u;}
        public String getName(){return name;} public double getQuantity(){return quantity;} public String getUnit(){return unit;}
    }
}
